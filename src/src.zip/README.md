# FactuCyC

---

## Integrantes

* Fernanda Fernandez @Ferfdz1995
* Irvin Gonzalez
* Danilo Obando
* Daniel Coto @danielCQgt4

---
