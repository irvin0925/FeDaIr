<footer class="footer text-white p-4">
    <div class="text-center mt-1">
        <p>FideStore@cycwebservice.cf</p>
    </div>
</footer>

<script src="http://<?= $_SERVER['HTTP_HOST']; ?>/Assets/JS/general.js"></script>
</body>

</html>