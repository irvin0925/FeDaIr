<?php
include './Partials/headerClient.php';
?>

<div class="mt-2 box-center-h box-acerca text-accent border-solid border-w-1 w-90 mb-10">
    <h2 class="text-left ">Fide Store</h2>
    <hr class="mt-1 mb">
    <p class="text-accent">Este es un proyecto de Ambiente web en la unversidad Fidelitas Costa Rica,
        el proyecto consta de una tienda virtual.
    </p>
</div>
<?php
include './Partials/footerClient.php';
?>